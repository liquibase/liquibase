package org.liquibase.ide.common.change.wizard.page;

public interface SingleValueWizardPage extends RefactorWizardPage {
     String getValue();
}
