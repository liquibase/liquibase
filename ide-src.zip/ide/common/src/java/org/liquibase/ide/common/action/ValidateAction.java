package org.liquibase.ide.common.action;

import liquibase.database.Database;
import liquibase.exception.LiquibaseException;
import liquibase.exception.ValidationFailedException;
import org.liquibase.ide.common.IdeFacade;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class ValidateAction extends MigratorAction {

    public ValidateAction() {
        super("Validate Change Log");
    }

    @Override
    public void actionPerform(Database database, IdeFacade ideFacade) throws LiquibaseException {
        String message;

        try {
            String changeLogFile = ideFacade.promptForChangeLogFile();
            if (changeLogFile == null) {
                return;
            }

            ideFacade.getLiquibase(changeLogFile, database).validate();
            message = "No validation errors found";
        } catch (ValidationFailedException e) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            e.printDescriptiveError(new PrintStream(byteArrayOutputStream));
            message = byteArrayOutputStream.toString();
        } catch (Exception e) {
            throw new LiquibaseException(e);
        }

        ideFacade.showOutput("Change Log Status", message);

    }

    @Override
    public boolean needsRefresh() {
        return false;
    }


}
