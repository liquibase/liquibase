package org.liquibase.ide.common.dialog;

public interface DisplayOutputDialog {
}
