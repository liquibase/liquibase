package org.liquibase.intellij.plugin.action;

import dbhelp.plugin.action.portable.PortableAction;

public abstract class BaseDatabaseAction extends PortableAction {

    public BaseDatabaseAction(String name) {
        super(name);
    }


}
