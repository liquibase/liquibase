package org.liquibase.intellij.plugin;

import org.liquibase.ide.common.ProgressMonitor;

class IntellijProgressMonitor implements ProgressMonitor {

    public void beginTask(String title, int workTotal) {
        ;
    }

    public void subTask(String title) {
        ;
    }

    public void worked(int amount) {
        ;
    }

    public void done() {
        ;
    }
}
